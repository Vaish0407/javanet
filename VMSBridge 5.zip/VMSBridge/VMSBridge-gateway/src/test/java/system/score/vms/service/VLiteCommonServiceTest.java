package system.score.vms.service;


import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;

//@ExtendWith(MockitoExtension.class)
public class VLiteCommonServiceTest {
/*
    @Mock
    private VLiteCommonApiClient vLiteCommonApiClient;

    private VLiteCommonService vLiteCommonService;

    @BeforeEach
    void setUp() {
        vLiteCommonService = new VLiteCommonService(vLiteCommonApiClient);
    }

    @Test
    void testInitialize_Success() throws RestClientException {
        // Given
        String licenseKey = "IH9-LQ1";
        int versionMajor = 1;
        int versionMinor = 0;
        VcInitializeRequest vliteInitializeRequest = new VcInitializeRequest();
        vliteInitializeRequest.setLicenseKey(licenseKey);
        vliteInitializeRequest.setVersionMajor(versionMajor);
        vliteInitializeRequest.setVersionMinor(versionMinor);
        VcInitializeResponse mockInitialiseResponse = createTestInitializeResp();
        when(vLiteCommonApiClient.initialize(any(VcInitializeRequest.class))).thenReturn(mockInitialiseResponse);
        /* when(vLiteCommonApiClient.initialize(argThat(req ->
                "IH9-LQ1".equals(req.getLicenseKey()) &&
                        req.getVersionMajor() == 1 &&
                        req.getVersionMinor() == 0
        ))).thenReturn(mockInitialiseResponse);
*/
    /*
        // When
        String result = vLiteCommonService.initialize(vliteInitializeRequest.getLicenseKey(),vliteInitializeRequest.getVersionMajor(),vliteInitializeRequest.getVersionMinor());
        JsonUtil jsonUtil = new JsonUtil();
        VcInitializeResponse resultObj = jsonUtil.fromJson(result, VcInitializeResponse.class);

        // Then
        assertThat(resultObj).isNotNull();
        assertThat(resultObj.getSuccess()).isEqualTo(mockInitialiseResponse.getSuccess());
        assertThat(resultObj.getErrorCode()).isEqualTo(mockInitialiseResponse.getErrorCode());
        assertThat(resultObj.getErrorMessage()).isEqualTo(mockInitialiseResponse.getErrorMessage());
        verify(vLiteCommonApiClient).initialize(vliteInitializeRequest);
    }

    @Test
    void testConnect_Success() throws RestClientException {
        // Given
        String ipAddress = "192.168.1.100";
        int port = 5000;
        String password =  "password";
        Boolean readOnly = false;
        VcConnectRequest vliteConnectRequest = new VcConnectRequest();
        vliteConnectRequest.setIpAddress(ipAddress);
        vliteConnectRequest.setPort(port);
        vliteConnectRequest.setPassword(password);
        vliteConnectRequest.setReadOnly(readOnly);
        VcConnectResponse mockConnectResponse = createTestConnectResp();
        when(vLiteCommonApiClient.connect(any(VcConnectRequest.class))).thenReturn(mockConnectResponse);
        // When
        String result = vLiteCommonService.connect(vliteConnectRequest.getIpAddress(),vliteConnectRequest.getPort(),vliteConnectRequest.getPassword(),vliteConnectRequest.getReadOnly());
        JsonUtil jsonUtil = new JsonUtil();
        VcConnectResponse resultObj = jsonUtil.fromJson(result, VcConnectResponse.class);

        // Then
        assertThat(resultObj).isNotNull();
        assertThat(resultObj.getSuccess()).isEqualTo(mockConnectResponse.getSuccess());
        assertThat(resultObj.getErrorCode()).isEqualTo(mockConnectResponse.getErrorCode());
        assertThat(resultObj.getErrorMessage()).isEqualTo(mockConnectResponse.getErrorMessage());
        assertThat(resultObj.getHubID()).isEqualTo(mockConnectResponse.getHubID());
        assertThat(resultObj.getHubSerialNo()).isEqualTo(mockConnectResponse.getHubSerialNo());
        verify(vLiteCommonApiClient).connect(vliteConnectRequest);
    }

    private VcConnectResponse createTestConnectResp() {
        VcConnectResponse vliteConnectresponse = new VcConnectResponse();
        vliteConnectresponse.setSuccess(true);
        vliteConnectresponse.setErrorCode(0);
        vliteConnectresponse.setErrorMessage("Success");
        vliteConnectresponse.setHubID(1);
        vliteConnectresponse.setHubSerialNo("SPU001234");
        return vliteConnectresponse;
    }

    @Test
    void testTemperature_Success() throws RestClientException{
        //Given
        int hubId = 1;
        VcTemperatureResponse mockTempRespone = createTemperatureRespone();
        when(vLiteCommonApiClient.temperature(hubId)).thenReturn(mockTempRespone);

        //When
        String result = vLiteCommonService.temperature(hubId);
        JsonUtil jsonUtil = new JsonUtil();
        VcTemperatureResponse resultObj = jsonUtil.fromJson(result, VcTemperatureResponse.class);

        //Then
        assertThat(resultObj).isNotNull();
        assertThat(resultObj.getSuccess()).isEqualTo(mockTempRespone.getSuccess());
        assertThat(resultObj.getErrorCode()).isEqualTo(mockTempRespone.getErrorCode());
        assertThat(resultObj.getErrorMessage()).isEqualTo(mockTempRespone.getErrorMessage());
        assertThat(resultObj.getTemperature()).isEqualTo(mockTempRespone.getTemperature());
        assertThat(resultObj.getUnit()).isEqualTo(mockTempRespone.getUnit());
        verify(vLiteCommonApiClient).temperature(hubId);
    }

    @Test
    void testDisconnect_Success() throws RestClientException{
        //Given
        int hubId = 1;
        VcDisconnectResponse mockDisconnectRespone = createDisconnectRespone();
        when(vLiteCommonApiClient.disconnect(hubId)).thenReturn(mockDisconnectRespone);

        //When
        String result = vLiteCommonService.disconnect(hubId);
        JsonUtil jsonUtil = new JsonUtil();
        VcDisconnectResponse resultObj = jsonUtil.fromJson(result, VcDisconnectResponse.class);

        //Then
        assertThat(resultObj).isNotNull();
        assertThat(resultObj.getSuccess()).isEqualTo(mockDisconnectRespone.getSuccess());
        assertThat(resultObj.getErrorCode()).isEqualTo(mockDisconnectRespone.getErrorCode());
        assertThat(resultObj.getErrorMessage()).isEqualTo(mockDisconnectRespone.getErrorMessage());
        assertThat(resultObj.getHubID()).isEqualTo(mockDisconnectRespone.getHubID());
        verify(vLiteCommonApiClient).disconnect(hubId);
    }

    private VcDisconnectResponse createDisconnectRespone() {

        VcDisconnectResponse vliteDisconnectResponse = new VcDisconnectResponse();
        vliteDisconnectResponse.setSuccess(true);
        vliteDisconnectResponse.setErrorCode(0);
        vliteDisconnectResponse.setErrorMessage("Success");
        vliteDisconnectResponse.setHubID(1);
        return  vliteDisconnectResponse;
    }

    /**
     * Helper method to create a test initialize response.
     */
    /*
    private VcInitializeResponse createTestInitializeResp() {

        VcInitializeResponse vliteInitializeResponse = new VcInitializeResponse();
        vliteInitializeResponse.setSuccess(true);
        vliteInitializeResponse.setErrorCode(0);
        vliteInitializeResponse.setErrorMessage("Success");
        return vliteInitializeResponse;
    }

    /**
     * Helper method to create a test temperature response.
     */
    /*
    private VcTemperatureResponse createTemperatureRespone(){
        VcTemperatureResponse vcTemperatureResponse = new VcTemperatureResponse();
        vcTemperatureResponse.setSuccess(true);
        vcTemperatureResponse.setErrorCode(0);
        vcTemperatureResponse.setErrorMessage("Success");
        vcTemperatureResponse.setTemperature(42);
        vcTemperatureResponse.setUnit("°C");
        return vcTemperatureResponse;
    }
    */

}
