package system.score.vms.designer;

import com.inductiveautomation.ignition.common.licensing.LicenseState;
import com.inductiveautomation.ignition.common.script.ScriptManager;
import com.inductiveautomation.ignition.designer.model.AbstractDesignerModuleHook;
import com.inductiveautomation.ignition.designer.model.DesignerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import system.score.vms.VLiteMain;

public class DesignerHook extends AbstractDesignerModuleHook {

    private final Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    public void startup(DesignerContext context, LicenseState activationState) throws Exception {
        super.startup(context, activationState);

        ScriptManager scriptManager = context.getScriptManager();scriptManager.addScriptModule("system.score.vms", new VLiteMain());
        logger.info("Registered system.score in Designer scope.");


    }

    @Override
    public void shutdown() {
        super.shutdown();
    }

}
